import logging
import sys

logging.basicConfig(stream=sys.stdout, format='%(message)s', level=logging.INFO)
